package Homework4_old;

public class ThreadDriver {
	
	
	static DatagramSendReceive d = new DatagramSendReceive();
	public static void main(String[] args){
		byte[] ip = {(byte)192, (byte)168, (byte)1, (byte)109};
		String message = "test";
		int port = 63000;
		//d.send(message, port, ip);
		d.init();
	}

}
